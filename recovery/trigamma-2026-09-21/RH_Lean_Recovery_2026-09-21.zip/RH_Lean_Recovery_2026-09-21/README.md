# RiemannResearch Lean recovery bundle

Recovered 21 September 2026 from the still-accessible isolated workspace.

## Status

All four new Lean modules are **unverified proof candidates**. No new declaration
has a successful Lean check in this task, and no new commit has been published.
Earlier snippet checks timed out after 120 and 600 seconds. The file check timed
out after 600 seconds. The publication checkpoint still reported running after
5,518 seconds (about 92 minutes), with no compiler output or updated build phase.
These outcomes neither prove nor refute the statements.

The reset tool rejected even its preview request with:

> Cannot reset while job job_kn3SXMzhgaXJhGaWaKgVYiDYqoOT-DYh is running; poll agent_workspace_job_status until it is terminal.

No reset, cancellation, service restart, or new verification submission was
performed. The available connector exposes no worker cancellation/restart action.
The original workspace and its changes were left intact.

## Recovered material

- `source/RiemannResearch/RH/CRTTrigammaMeanValue.lean`: unique actual digamma
  mean point; monotonicity in residue and conductor; geometric/arithmetic bounds;
  quantitative scaled error and fixed-residue limit.
- `source/RiemannResearch/LinearAlgebra/FiniteMatrixInverseComparison.lean`:
  variational inverse-energy comparison for actual positive finite Gram matrices.
- `source/RiemannResearch/RH/ProgressionMidpointInverse.lean`: relative weighted
  Gram comparison, inverse comparison, occupation error, and saturation-limit
  equivalence, with finite Gram positivity explicit.
- `source/RiemannResearch/RH/NonnegativeResidueObstruction.lean`: the two-site
  tail lower bound 2/27 for normalized nonnegative residue combinations.
- `source/RiemannResearch/RH/TrigammaMidpointSaturationResearch20260921.md`:
  informal arguments, signed Mobius trial, and the unresolved tail estimate.
- `restore.patch`: all five new files plus the root imports and catalog changes.
- `recovery_manifest.json`: source hashes, base commit, workspace and pending job.

The source scan found no `sorry`, `admit`, `axiom`, or `unsafe` tokens in these
four Lean files. This is only a source scan, not a compilation or axiom audit.

## Recovery and verification

Base commit: `8f9bec2691b96631b046ea2791943ca5a2dfd358`.

Workspace token: `ws_vtvPqH8WM2fKnuH5YO2on9FV4dl2GLnn`.

Workspace root:
`/home/cri_2025/lean-agent-workspaces/ws_vtvPqH8WM2fKnuH5YO2on9FV4dl2GLnn/RiemannResearch`.

Pending job: `job_kn3SXMzhgaXJhGaWaKgVYiDYqoOT-DYh`.

1. On the Lean host, inspect the existing build and worker logs. Determine whether
   the process is progressing, stalled, or stale in the queue database. The exact
   service name and process identity have not been discovered; do not blindly
   terminate all Lean processes or delete this workspace.
2. If recovery requires a worker restart, reconcile the existing checkpoint's
   status and ensure it is terminal before submitting more verification.
3. Prefer resuming the original workspace. To restore elsewhere, use a separate
   checkout at the base commit, first run `git apply --check` on `restore.patch`,
   and only then apply it. The patch is already applied in the original workspace.
   If the base has advanced, reconcile changes rather than force-applying.
4. Verify one module at a time, starting with `NonnegativeResidueObstruction`,
   then `FiniteMatrixInverseComparison`, then `CRTTrigammaMeanValue`, and finally
   `ProgressionMidpointInverse`. Repair actual diagnostics without placeholders.
5. Publish only after successful checks. Update the catalog to the actual verified
   status and record the resulting commit. Do not describe this archive as verified.

## Mathematical endpoint

The midpoint occupation is a probability, so its target is 1. The divergent
quantity is physical-tail capacity `C_N = 1/(2 U_N)`, where `U_N` is the minimum
weighted tail energy among legal combinations with value 1 at the first site.

The drafted comparison is `|q_N - qtilde_N| <= 1/(2 L_N + 3)^2`. It transfers a
saturation limit between exact and midpoint models but does not prove that limit.
Signed cancellation is necessary: nonnegative coefficients force tail energy at
least 2/27. Capacity divergence, vanishing tail energy for the signed candidate,
and RH remain unproved. Strict decrease of `L alpha_{r,L}` in `L` is only recorded
informally and has not been formalized in the new modules.
